
from django.contrib import admin
from django.conf.urls import url, include
# from django.conf.urls import include



urlpatterns = [
    # path(r'^admin/', admin.site.urls),
    url('', include('To_do_list1.urls')),
    
]
