# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect
from django.http import HttpResponse
# from forms import ListForm
# from django.contrib import messages
# from .models import List


# Create your views here.

def home(request):

	return render(request, "home.html")


def add(request):

	if request.method == 'POST':
		x = int(request.POST.get('num1'))
		y = int(request.POST.get('num2'))
		res = x + y

	

	return render(request, "home.html", {'result': res})

def sub(request):
	if request.method == 'POST':
		x = int(request.POST.get('num1'))
		y = int(request.POST.get('num2'))
		res = x - y

	return render(request, "home.html", {'result': res})

def mul(request):
	if request.method == 'POST':
		x = float(request.POST.get('num1'))
		y = float(request.POST.get('num2'))
		res = x * y

	return render(request, "home.html", {'result': res})

def div(request):
	if request.method == 'POST':
		x = float(request.POST.get('num1'))
		y = float(request.POST.get('num2'))
		res = x / y

	return render(request, "home.html", {'result': res})



if __name__ == '__main__':
	To_do_list1()


# def calc(request):
# 	if request.method == 'POST':
# 		val1 = int(request.POST.get('num1'))
# 		val2 = int(request.POST.get('num2'))
# 		res = val1 + val2

# 	return render(request, "home.html", {'result': res})


# def home(request):

# 	if request.method == 'POST':
# 		form = ListForm(request.POST or None)

# 		if form.is_valid():
# 			form.save()
# 			all_items = List.objects.all
# 			messages.success(request, ('Item has been added to the Bucket'))
# 			return render(request, 'home.html', {'all_items': all_items})

# 	else:
# 		all_items = List.objects.all
# 		return render(request, 'home.html', {'all_items': all_items})


# 	# return render(request, 'home.html', {})





	