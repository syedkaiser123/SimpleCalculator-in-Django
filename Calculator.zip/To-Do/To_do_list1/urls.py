
from django.conf.urls import url, include
from django.contrib import admin
# from django.conf.urls import path, include
from . import views


urlpatterns = [
    url(r'^$', views.home, name='home'),
  
    url(r'^add', views.add, name='add'),
    url(r'^sub', views.sub, name='sub'),
    url(r'^mul', views.mul, name='mul'),
    url(r'^div', views.div, name='div'),
    
]
